export class MyDiagnosticCentre{
    centreId: String;
	centreName: String;
	centreAddress: String;
}
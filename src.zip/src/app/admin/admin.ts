export class Admin {
    id:Number;
    name:String;
    password:String;
    email:String;
    gender:String;
    userRole:String;   
}

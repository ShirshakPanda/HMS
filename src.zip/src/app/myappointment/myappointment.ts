export class MyAppointment{
    appointmentId: Number;
	userId: Number;
	diagnosticCentreId: Number;
	testId: Number;
	date1: String;
	time1: String;
	totalCost: Number;
	approved: Boolean;
}